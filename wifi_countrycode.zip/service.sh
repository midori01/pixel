#!/system/bin/sh
MODDIR=${0%/*}

Wait_until_login() {
  while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
  done

  while [ ! -d "/sdcard/Android" ]; do
    sleep 1
  done
}
Wait_until_login

sleep 5
#chmod 777 /sys/class/meizu/main_tp/game_mode_node
#echo 1 > /sys/class/meizu/main_tp/game_mode_node
#chmod 444 /sys/class/meizu/main_tp/game_mode_node

cmd wifi force-country-code enabled US
cmd wifi set-wifi-enabled disabled
cmd wifi set-wifi-enabled enabled