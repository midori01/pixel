#!/system/bin/sh
MODDIR=${0%/*}
am start -n com.google.mds/com.google.mds.startup.HomeActivity
