#!/system/bin/sh
MODDIR=${0%/*}
Wait_until_login() {
  while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
  done
  while [ ! -d "/sdcard/Android" ]; do
    sleep 1
  done
}
Wait_until_login
sleep 5
/vendor/bin/vcd
