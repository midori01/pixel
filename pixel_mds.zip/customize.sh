set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/system/vendor/bin/vcd 0 0 0755
