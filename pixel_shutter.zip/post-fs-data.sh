#!/system/bin/sh
setprop audio.camerasound.force false
