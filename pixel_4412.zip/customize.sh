set_perm_recursive $MODPATH 0 0 0755 0644
chcon -R u:object_r:vendor_engineermode_app:s0 "$MODPATH/system/priv-app/EngineerMode"
