#!/system/bin/sh

MODDIR=${0%/*}

key_check() {
    while true; do
        key_check=$(/system/bin/getevent -qlc 1)
        key_event=$(echo "$key_check" | awk '{ print $3 }' | grep 'KEY_')
        key_status=$(echo "$key_check" | awk '{ print $4 }')
        if [[ "$key_event" == *"KEY_"* && "$key_status" == "DOWN" ]]; then
            keycheck="$key_event"
            break
        fi
    done
    while true; do
        key_check=$(/system/bin/getevent -qlc 1)
        key_event=$(echo "$key_check" | awk '{ print $3 }' | grep 'KEY_')
        key_status=$(echo "$key_check" | awk '{ print $4 }')
        if [[ "$key_event" == *"KEY_"* && "$key_status" == "UP" ]]; then
            break
        fi
    done
}

echo "切换WiFi的地区
- 音量↑ AU
- 音量↓ US"
key_check
case "$keycheck" in
    "KEY_VOLUMEUP")
        cmd wifi force-country-code enabled AU
        cmd wifi set-wifi-enabled disabled
        cmd wifi set-wifi-enabled enabled
    ;;
    "KEY_VOLUMEDOWN")
        cmd wifi force-country-code enabled US
        cmd wifi set-wifi-enabled disabled
        cmd wifi set-wifi-enabled enabled
    esac
    
            

echo "当前WiFi地区"
echo "$(cmd wifi get-country-code)"
echo "完成"
